﻿var FormValidation = function () {

    var ls = new SecureLS({ encodingType: 'aes' });

    var PageBlock = function () {
        $.blockUI({ message: $('#loading') });
    }

    var OnFormLoad = function () {

        var deferred = $.Deferred();
        deferred
            .then(function () {
                GetToken();
            })
            .then(function () {
                Getgcaptcha();
            })
            .then(function () {
                //RenderChangeAfterWindowResize();
            })
            .then(function () {
                //OnResize();
            })
            .then(function () {

                $("#login_btn").on('click', function () {
                    var password = $("#password").val()
                    $(".password_helper").text("")
                    if (password == "F@zaaExpo2o2o") {
                        $(".password_helper").text("")
                        $("#password").css("border-color", "none")
                        window.location = "welcome.html"
                    }
                    else if (password == "" || password == null) {
                        $(".password_helper").text("Enter password to continue")
                        $("#password").css("border-color", "red")
                    }
                    else {
                        $(".password_helper").text("Incorrect password")
                        $("#password").css("border-color", "red")
                    }
                });


                $('form input[type="text"]').on('keypress keydown keyup', function (e) {
                    if (e.keyCode == 13) { e.preventDefault(); }
                });

                // $("#FirstName")
                //     .on("keypress keydown keyup", function (e) {
                //         return AcceptEnglishCharactersOnly(e);
                //     });

                $('#CheckIn,#CheckOut').datepicker({
                    format: 'dd-mm-yyyy',
                    autoHide: true,
                    startView: 2
                }).on('change', function () {
                    $('.datepicker').hide();
                    $(this).valid();
                });

                $("#Mobile")
                    .on("keypress", function (e) {
                        return IsNumberKey(e);
                    });

                $("#getCode").on("click", function () {
                    var url = "https://fz.fazaa.ae/fazaaforms/forms/expo/expo_register.html"
                    timer(10)
                    var hash = GetHashCode()
                    var encoded = encodeURIComponent(hash)
                    console.log(encoded)
                    if (encoded !== undefined) {
                        $("#btn_container").hide()
                        $("#qr_container img").attr('src', 'https://chart.googleapis.com/chart?cht=qr&chs=500x500&chl=' + url + '?em=' + encoded)
                        $("#qr_container").show()
                        setTimeout(() => {
                            location.reload();
                        }, 5000);
                    }
                    else {
                        $("#btn_container .hasherror").text("Something went wrong. Please try again!!!")
                    }
                })
            })
            .then(function () {
                const urlParams = new URLSearchParams(window.location.search);
                const param_x = urlParams.get('em');
                var response = Get_CallHandler("https://prdprtapi.fazaa.ae/api/expo/usedFlagNew/" + param_x)
                if (response.httpstatuscode == 200) {
                    console.log(response.responsebody.usedFlag)
                    if (response.responsebody.usedFlag === 0) {
                        $('#d-flag').removeClass("disable")
                    }
                    else {
                        $('.alert-error').css("display", "block")
                        $('.alert-error .alert-error-msg').text("Invalid Page")
                    }
                }
                else if (response.httpstatuscode == 401) {
                    $('.alert-error').css("display", "block")
                    $('.alert-error .alert-error-msg').text("Invalid Page")
                }
                else if (response.httpstatuscode == 422) {
                    $('.alert-error').css("display", "block")
                    $('.alert-error .alert-error-msg').text("Invalid Page")
                }
            });
        deferred.resolve();
    }

    var GetToken = function () {
        var response = Get_CallHandler("https://prdprtapi.fazaa.ae/api/Token");
        if (response.httpstatuscode == 200) {
            ls.set('ടോക്കൺ', response.responsebody.token);
        }
    }


    var GetHashCode = function () {
        var response = Post_CallHandler("https://prdprtapi.fazaa.ae/api/expo/generateHashedCode");
        if (response.httpstatuscode == 200) {
            return response.responsebody.hashCode
            console.log(response.responsebody.hashCode)
        }
    }

    var Getgcaptcha = function () {
        grecaptcha.ready(() => {
            grecaptcha.render('dvCaptcha', {
                // 'sitekey': '6LeIxAcTAAAAAJcZVRqyHh71UMIEGNQ_MXjiZKhI',
                'sitekey': '6LfFhNsZAAAAAHqL0_1YfbWrDajenYM1JkDjT5Jx',
                'expired-callback': function (response) {
                    grecaptcha.reset();
                },
                'callback': function () {
                    $("#OnClientValidate_Captcha").addClass("display-hide");
                    $("#OnClientValidate_Captcha").pulsate("destroy");
                }
            });
        });
    }

    var RenderChangeAfterWindowResize = function () {
        let width = window.innerWidth;
        if (width <= 500) {
            $("#dvCaptcha").removeClass("align-items-center");
        }
        else {
            $("#dvCaptcha").addClass("align-items-center");
        }
    }

    var OnResize = function () {
        let resizeId;
        PageBlock();
        $(window).resize(function () {
            clearTimeout(resizeId);
            resizeId = setTimeout(function () {
                RenderChangeAfterWindowResize();
                setTimeout(function () { $.unblockUI(); }, 1000);
            }, 500);
        });
    }

    var AcceptArabicCharactersOnly = function (evt) {
        var arabicCharUnicodeRange = /[\u0600-\u06FF]/;
        var key = event.which;
        // 0 = numpad
        // 8 = backspace
        // 32 = space
        // 37 = Left arrow
        // 39 = Right arrow
        if (evt.keyCode == 8 || evt.keyCode == 37 || evt.keyCode == 39 || key == 0 || key === 32) {
            return true;
        }
        var str = String.fromCharCode(key);
        if (arabicCharUnicodeRange.test(str)) {
            return true;
        }
        return false;
    }

    var AcceptEnglishCharactersOnly = function (evt) {
        var EnglishCharUnicodeRange = /[A-Za-z ]/g;
        var key = event.which;
        // 0 = numpad
        // 8 = backspace
        // 32 = space
        // 37 = Left arrow
        // 39 = Right arrow
        if (evt.keyCode == 8 || evt.keyCode == 37 || evt.keyCode == 39 || key == 0 || key === 32) {
            return true;
        }
        var str = String.fromCharCode(key);
        if (EnglishCharUnicodeRange.test(str)) {
            return true;
        }
        return false;
    }

    var IsNumberKey = function (evt) {
        var charCode = (evt.which) ? evt.which : event.keyCode
        if (charCode > 31 && (charCode < 48 || charCode > 57) && charCode != 46)
            return false;
        else {
            var len = $(evt.currentTarget).val().length;
            var index = $(evt.currentTarget).val().indexOf('.');
            if (index > 0 && charCode == 46) {
                return false;
            }
            if (index > 0) {
                var CharAfterdot = (len + 1) - index;
                if (CharAfterdot > 3) {
                    return false;
                }
            }
        }
        return true;
    }

    var generate_randomnumber = function (length) {
        var arr = [];
        var n;
        for (var i = 0; i < length; i++) {
            do
                n = Math.floor(Math.random() * 20 + 1);
            while (arr.indexOf(n) !== -1)

            arr[i] = n;
        }

        return arr.toString().replace(/,/g, "");
    }

    var generate_randomstring = function (length) {
        var result = '';
        var characters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
        var charactersLength = characters.length;
        for (var i = 0; i < length; i++) {
            result += characters.charAt(Math.floor(Math.random() * charactersLength));
        }
        return result;
    }

    var getdate = function () {
        var d = new Date,
            dformat = d.getDate() + '-' + (d.getMonth() + 1) + '-' + d.getFullYear() + '_' + d.getHours() + '-' + d.getMinutes() + 1 + '-' + d.getSeconds();

        return dformat;
    }

    var ConvertToEnglishdigit = function (arDigit) {
        var newValue = "";
        for (var i = 0; i < arDigit.length; i++) {
            var ch = arDigit.charCodeAt(i);
            if (ch >= 1776 && ch <= 1785) {// PERSIAN
                var newChar = ch - 1728;
                newValue = newValue + String.fromCharCode(newChar);
            }
            else if (ch >= 1632 && ch <= 1641) {// ARABIC
                var newChar = ch - 1584;
                newValue = newValue + String.fromCharCode(newChar);
            }
            else {
                newValue = newValue + String.fromCharCode(ch);
            }
        }
        return newValue;
    }

    var Post_CallHandler = function (c_url, c_data) {
        var response = {};

        $.ajax({
            type: "POST",
            contentType: "application/json; charset=utf-8",
            url: c_url,
            data: c_data,
            dataType: "json",
            async: false,
            cache: false,
            //headers: { "Authorization": ls.get('ടോക്കൺ') },
            headers: { "Authorization": "Bearer " + ls.get('ടോക്കൺ') },
            success: function (data, textStatus, xhr) {
                response.httpstatuscode = xhr.status;
                response.responsebody = data;
            },
            error: function (xhr, textStatus, error) {
                if (typeof console == "object") {
                    response.httpstatuscode = xhr.status;
                    response.responsebody = error;
                    //console.log(xhr.status + "," + xhr.responseText + "," + textStatus + "," + error);
                }
            }
        });
        return response;
    }
    var Save_CallHandler = function (c_url, c_data) {
        var response = {};

        $.ajax({
            type: "POST",
            contentType: "application/json; charset=utf-8",
            url: c_url,
            data: c_data,
            dataType: "json",
            async: false,
            cache: false,
            //headers: { "Authorization": ls.get('ടോക്കൺ') },
            // headers: { "Authorization": "Bearer " + ls.get('ടോക്കൺ') },
            beforeSend: function (x) {
                if (x && x.overrideMimeType) {
                    x.overrideMimeType("application/j-son;charset=UTF-8");
                }
            },
            success: function (data, textStatus, xhr) {
                response.httpstatuscode = xhr.status;
                response.responsebody = data;
            },
            error: function (xhr, textStatus, error) {
                if (typeof console == "object") {
                    response.httpstatuscode = xhr.status;
                    response.responsebody = error;
                    //console.log(xhr.status + "," + xhr.responseText + "," + textStatus + "," + error);
                }
            }
        });
        return response;
    }

    var Put_CallHandler = function (c_url, c_data) {
        var response = {};
        $.ajax({
            type: "PUT",
            contentType: "application/json; charset=utf-8",
            url: c_url,
            data: c_data,
            dataType: "json",
            async: false,
            cache: false,
            //headers: { "Authorization": ls.get('ടോക്കൺ') },
            headers: { "Authorization": "Bearer " + ls.get('ടോക്കൺ') },
            beforeSend: function (x) {
                if (x && x.overrideMimeType) {
                    x.overrideMimeType("application/j-son;charset=UTF-8");
                }
            },
            success: function (data, textStatus, xhr) {
                response.httpstatuscode = xhr.status;
                response.responsebody = data;
            },
            error: function (xhr, textStatus, error) {
                if (typeof console == "object") {
                    response.httpstatuscode = xhr.status;
                    response.responsebody = error;
                    //console.log(xhr.status + "," + xhr.responseText + "," + textStatus + "," + error);
                }
            }
        });
        return response;
    }

    var Get_CallHandler = function (c_url) {
        var response = {};
        $.ajax({
            type: "GET",
            contentType: "application/json; charset=utf-8",
            url: c_url,
            dataType: "",
            async: false,
            cache: false,
            //headers: { "Authorization": ls.get('ടോക്കൺ') },
            headers: { "Authorization": "Bearer " + ls.get('ടോക്കൺ') },
            success: function (data, textStatus, xhr) {
                response.httpstatuscode = xhr.status;
                response.responsebody = data;
            },
            error: function (xhr, textStatus, error) {
                if (typeof console == "object") {
                    response.httpstatuscode = xhr.status;
                    response.responsebody = error;
                    //console.log(xhr.status + "," + xhr.responseText + "," + textStatus + "," + error);
                }
            },
            complete: function () {
                $('.icon-container').remove();
            }
        });

        return response;
    }


    var FileUpload_CallHandler = function (c_url, c_data) {
        var response = {};

        $.ajax({
            type: "POST",
            contentType: "application/json; charset=utf-8",
            url: c_url,
            data: c_data,
            dataType: "json",
            async: false,
            cache: false,
            contentType: false,
            processData: false,
            //headers: { "Authorization": ls.get('ടോക്കൺ') },
            success: function (data, textStatus, xhr) {
                response.httpstatuscode = xhr.status;
                response.responsebody = data;
                progressval(60);
                $("div.panel-body h4").html('Please wait... Submitting your application ');
            },
            error: function (xhr, textStatus, error) {
                if (typeof console == "object") {
                    response.httpstatuscode = xhr.status;
                    response.responsebody = error;
                    //console.log(xhr.status + "," + xhr.responseText + "," + textStatus + "," + error);
                }
            }
        });

        return response;
    }

    var FormatEID = function (val) {
        var nval = val;
        var lastChar = val[val.length - 1];
        var bool = $.isNumeric(lastChar);
        if (bool === false) {
            nval = val.slice(0, -1)
        }
        return nval;
    }

    var isObject = function (val) {
        if (val === null) { return false; }
        return ((typeof val === 'function') || (typeof val === 'object'));
    }

    var handleFormValidation = function () {

        let AlreadyExistEID_ErrorMsg = "";
        let emailExists_ErrorMsg = "";
        let mobilelExists_ErrorMsg = "";


        $.validator.addMethod(
            "regex",
            function (value, element, regexp) {
                var re = new RegExp(regexp);
                return this.optional(element) || re.test(value);
            }
        );

        $.validator.addMethod(
            "Chars_EnglishOnly",
            function (evt) {
                var EnglishCharUnicodeRange = /[A-Za-z ]/g;
                var key = evt.which;
                // 0 = numpad
                // 8 = backspace
                // 32 = space
                // 37 = Left arrow
                // 39 = Right arrow
                if (evt.keyCode == 8 || evt.keyCode == 37 || evt.keyCode == 39 || key == 0 || key === 32) {
                    return true;
                }
                var str = String.fromCharCode(key);
                if (EnglishCharUnicodeRange.test(str)) {
                    return true;
                }
                return false;
            }
        );


        $.validator.addMethod(
            "OnClientValidate_MemberShipNo",
            function (value, element, regexp) {
                if (value.trim() != "") {

                    var val = ConvertToEnglishdigit(value.trim());
                    $(element).val(val);

                    if (/^[0-9]{7,}$/.test(val)) {
                        return true;
                    }
                    else {
                        return false;
                    }
                }
                else {
                    return true;
                }
            }
        );

        $.validator.addMethod(
            "OnClientValidate_IsPlatinumMember",
            function (value, element, regexp) {
                var response = Get_CallHandler("https://prdprtapi.fazaa.ae/api/fetchMembership/" + value);
                $("#d-flag").addClass("disable");

                var memberLevel = response.responsebody.level;
                memberLevel = memberLevel.toLowerCase().replace(/\b[a-z]/g, function (letter) {
                    return letter.toUpperCase();
                });
                var memberStatus = response.responsebody.membershipStatus;
                memberStatus = memberStatus.toLowerCase().replace(/\b[a-z]/g, function (letter) {
                    return letter.toUpperCase();
                });

                if (response.httpstatuscode == 200) {
                    ($("#MemberId").val(response.responsebody.membershipNo))
                    if (memberLevel === "Platinum") {
                        if (memberStatus === "Active") {
                            $("#d-flag").removeClass("disable");
                            return true;
                        }
                        else {
                            AlreadyExistEID_ErrorMsg = "Dear member, your membership is not active. Kindly reactivate or please call 600520003 to update your information.";
                            return false;
                        }
                    }
                    else {
                        AlreadyExistEID_ErrorMsg = "Dear member, you cannot apply for this program. The service is exclusive for members with an active platinum membership.";
                        return false;
                    }
                }

                else if (response.httpstatuscode == 401) {
                    AlreadyExistEID_ErrorMsg = "Sorry you are not authorized to access this site";
                    return false;
                }
                else if (response.httpstatuscode == 404) {
                    AlreadyExistEID_ErrorMsg = "Membership number does not exist.";
                    return false;
                }
            },
            function () {
                return AlreadyExistEID_ErrorMsg;
            });

        $.validator.addMethod(
            "validateFullname",
            function (value, element, regexp) {
                if (/^([a-zA-Z]{2,}\s[a-zA-z]{1,}'?-?[a-zA-Z]{2,}\s?([a-zA-Z]{1,})?)/.test(value)) {
                    return true
                }
                else {
                    return false
                }
            }
        )

        $.validator.addMethod(
            "checkEmailExists",
            function (value, element, regexp) {
                var response = Get_CallHandler("https://fz.fazaa.ae/mmsapilv/api/Fetch/FetchDetails?searchby=" + value)
                if (response.httpstatuscode == 200) {
                    emailExists_ErrorMsg = "Email already exists";
                    return false;
                }
                else {
                    return true
                }
            },
            function () {
                return emailExists_ErrorMsg;
            });

        $.validator.addMethod(
            "checkMobileExists",
            function (value, element, regexp) {
                var trimmedNo = value.substr(value.length - 9);
                var mobToCheck = "971" + trimmedNo
                var response = Get_CallHandler("https://fz.fazaa.ae/mmsapilv/api/Fetch/FetchDetails?searchby=" + trimmedNo)
                if (response.httpstatuscode == 200) {
                    mobilelExists_ErrorMsg = "Mobile Number already exists";
                    return false;
                }
                else {
                    return true
                }
            },
            function () {
                return mobilelExists_ErrorMsg;
            });


        $.validator.addMethod(
            "OnClientValidate_EngField",
            function (value, element, regexp) {
                var val = value.trim();
                if (val != "") {
                    var isvalid = false;
                    var values = val.split(' ').filter(function (v) { return v !== '' });
                    var count = 0;
                    for (var i = 0; i < val.length; i++) {
                        var c = val.codePointAt(i);
                        if ((c >= 0x041 && c <= 0x05A) || (c >= 0x061 && c <= 0x07A) || (c == 0x20)) {
                            count = count + 1;
                        }
                    }
                    if ((count == val.length && (values.length > 1))) {
                        return true;
                    }
                    else {
                        return false;
                    }
                }
                else {
                    return true;
                }
            }
        );

        $.validator.addMethod(
            "OnClientValidate_Name",
            function (value, element, regexp) {
                var val = value.trim();
                if (val != "") {
                    var isvalid = false;
                    var count = 0;
                    for (var i = 0; i < val.length; i++) {
                        var c = val.codePointAt(i);
                        if ((c >= 0x041 && c <= 0x05A) || (c >= 0x061 && c <= 0x07A) || (c == 0x20)) {
                            count = count + 1;
                        }
                    }
                    if ((count == val.length)) {
                        return true;
                    }
                    else {
                        return false;
                    }
                }
                else {
                    return true;
                }
            }
        );

        $.validator.addMethod(
            "OnClientValidate_MobileNo",
            function (value, element, regexp) {
                if (value.trim() != "") {
                    var val = ConvertToEnglishdigit(value.trim());
                    $(element).val(val);
                    if (/^(\+971|0|971|00971|)(50|52|54|55|56|58)\d{7}$/.test(val)) {
                        return true;
                    }
                    else {
                        return false;
                    }
                }
                else {
                    return true;
                }
            }
        );

        $('#register-form').validate({
            errorElement: 'span',
            errorClass: 'help-block',
            focusInvalid: false,
            ignore: "",
            onfocusout: function (element) {
                $(element).valid();
            },
            rules: {
                FirstName: {
                    required: true,
                    OnClientValidate_Name: true,
                    validateFullname: true,
                    Chars_EnglishOnly: true
                },
                Mobile: {
                    required: true,
                    OnClientValidate_MobileNo: true,
                    checkMobileExists: true
                },
                Email: {
                    required: true,
                    regex: /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/,
                    checkEmailExists: true
                }
            },
            messages: {
                FirstName: {
                    required: 'Please enter your full name',
                    OnClientValidate_Name: "Please enter your full name",
                    validateFullname: "Please enter your full name",
                    Chars_EnglishOnly: "Please enter your full name in english only"
                },
                Mobile: {
                    required: 'Please enter valid mobile number',
                    OnClientValidate_MobileNo: "Mobile number is not valid",
                    // checkMobileExists: "Mobile number is already registered"
                },
                Email: {
                    required: 'Please enter valid email id',
                    regex: "Email address is not valid",
                    // checkEmailExists: "Email address is already registered"
                }
            },
            invalidHandler: function (event, validator) { },//display error alert on form submit            
            highlight: function (element) { // hightlight error inputs
                $(element).closest('.form-group').addClass('has-error'); // set error class to the control group
            },
            unhighlight: function (element) { // revert the change done by hightlight
                $(element).closest('.form-group').removeClass('has-error'); // set error class to the control group
            },
            success: function (label, element) {
                label.closest('.form-group').removeClass('has-error');
                label.remove();

                var icon = $(element).closest('.has-icons-right').children('i');
                $(element).closest('.form-group').removeClass('has-error').addClass('has-success'); // set success class to the control group
                icon.removeClass("fa-warning").addClass("fa-check");
            },
            errorPlacement: function (error, element) {

                $($(element).closest('.form-group')).append(error);
                $(element).closest('.form-group').removeClass('has-success').addClass('has-error');

                var icon = $(element).closest('.has-icons-right').children('i');
                icon.removeClass('fa-check').addClass("fa-warning");
                icon.attr("data-original-title", error.text()).tooltip({ 'container': 'body' });

                if ($(element).attr('name') == "country") {
                    $("#country-error").prependTo($($(element).closest('.form-group')).find('label').next());
                }

            },
            submitHandler: function (form, event) {
                const urlParams = new URLSearchParams(window.location.search);
                const emParam = urlParams.get('em');
                var data = { hashCode: emParam }
                // var userMob = $('#Mobile').val()
                // var userEmail = $('#Email').val()
                // var trimmedNo = userMob.substr(userMob.length - 9);
                // var response = Get_CallHandler("https://fz.fazaa.ae/mmsapilv/api/Fetch/FetchDetails?searchby=" + trimmedNo)
                // if (response.httpstatuscode == 200) {
                //     var mobToCheck = "971" + trimmedNo
                //     if (response.responsebody[0].MobileNo == mobToCheck) {
                //         if (response.responsebody[0].CCID == 705 || response.responsebody[0].CCID == 710) {
                //             $('#d-flag').addClass('disable')
                //             $('.alert-error').css("display", "block")
                //             $('.alert-error .alert-error-msg').text("You are already registered!!")
                //         }
                //         else if (response.responsebody[0].Email1 == userEmail) {
                //             if (response.responsebody[0].CCID == 705 || response.responsebody[0].CCID == 710) {
                //                 $('#d-flag').addClass('disable')
                //                 $('.alert-error').css("display", "block")
                //                 $('.alert-error .alert-error-msg').text("You are already registered!!")
                //             }
                //         }
                //         else {
                //             const checkValid = Put_CallHandler('https://prdprtapi.fazaa.ae/api/expo/updateHashCode', JSON.stringify(data))
                //             if (checkValid.httpstatuscode == 200) {
                //                 var response = grecaptcha.getResponse();
                //                 if (response.length != 0) {
                //                     SubmitForm();
                //                 }
                //                 else {
                //                     $("#OnClientValidate_Captcha").removeClass("display-hide");
                //                     $("#OnClientValidate_Captcha").pulsate({
                //                         color: "#bf1c56"
                //                     });
                //                 }
                //             }
                //             else {
                //                 $('#d-flag').addClass('disable')
                //                 $('.alert-error').css("display", "block")
                //                 $('.alert-error .alert-error-msg').text("Invalid Page")
                //             }
                //         }
                //     }
                // }
                const checkValid = Put_CallHandler('https://prdprtapi.fazaa.ae/api/expo/updateHashCode', JSON.stringify(data))
                if (checkValid.httpstatuscode == 200) {
                    var response = grecaptcha.getResponse();
                    if (response.length != 0) {
                        SubmitForm();
                    }
                    else {
                        $("#OnClientValidate_Captcha").removeClass("display-hide");
                        $("#OnClientValidate_Captcha").pulsate({
                            color: "#bf1c56"
                        });
                    }
                }
                else {
                    $('#d-flag').addClass('disable')
                    $('.alert-error').css("display", "block")
                    $('.alert-error .alert-error-msg').text("Invalid Page")
                }
            }
        });

    }

    var SubmitForm = function () {
        $.blockUI({
            css: {
                "border": "none",
                "background-color": "transparent",
                "top": "50%",
                "left": "50%",
                "margin-right": "-50%",
                "transform": "translate(-50%, -50%)",
                "-ms-transform": "translate(-50%, -50%)",   /* IE 9 */
                "-webkit-transform": "translate(-50%, -50%)",   /* Chrome, Safari, Opera */
                "width": "80%"
            },
            message: $(".panel-default"),
            onBlock: function () {
                $("progress-bar").removeClass("bg-danger");
                $("progress-bar").removeClass("bg-success");
                $("div.panel-body h4").html("Please wait... We are processing your request. ");

                var deferred = $.Deferred();

                deferred
                    .then(function () {
                        setTimeout(function () {
                            progressval(30);
                            UploadFiles();
                        }, 1000);
                    })

                deferred.resolve();
            }
        });
    }

    var UploadFiles = function () {
        progressval(60);
        $("div.panel-body h4").html("Please wait... Uploading your documents ");
        setTimeout(function () {
            var savefile = SaveFiles();
            if (savefile.responsebody == "file uploaded") {
                SaveOnSubmit();
            }
            else {
                setTimeout(function () {
                    progressval(100);
                    $(".progress-bar").addClass("bg-danger");
                    $("div.panel-body h4").html('Something went wrong while uploading your file.');
                }, 1000);
            }
        }, 1000);
    }

    var SaveFiles = function () {
        let formData = new FormData();
        let file_count = 0;
        $('form').find('input[type="file"]').each(function (index, fileupload) {
            if ($('form').validate().element($(fileupload))) {
                if ($(fileupload).get(0).files.length != 0) {
                    file_count = file_count + 1;
                    formData.append($(fileupload).next().html(), $(fileupload).get(0).files[0]);
                }
            }
        });

        let formData_count = 0;
        for (let value of formData.values()) {
            formData_count = formData_count + 1;
        }

        if (file_count != 0) {
            if (file_count == formData_count) {
                return FileUpload_CallHandler("../../api/Tawteen/UploadFile", formData);
            }
        }
        else {
            var response = {};
            response.responsebody = "file uploaded";
            progressval(60);
            $("div.panel-body h4").html('Please wait... Submitting your application ');
            return response;
        }
    }

    var SaveOnSubmit = function () {
        setTimeout(function () {
            var saverecords = SaveRecords();
            progressval(80);
            $("div.panel-body h4").html('Please wait... Finalizing Your Request');
            if (saverecords.httpstatuscode == 201) {//$.isNumeric(ApplnId)
                setTimeout(function () {
                    $("div.panel-body h4").html('Thank you, you have successfully applied.');
                    $("div.panel-body").append('<div class="divider"></div><div class="apparent-message success-message">'
                        + '<div class="message-container">'
                        + '<div class="apparent-message-icon fa fa-fw fa-2x fa-exclamation-triangle">'
                        + '</div>'
                        + '<div class="content-container">'
                        + '<div class="message-body"><h4>Note : </h4> Fazaa is revising your request and we will come back to you once we are done.</div>'
                        + '</div>'
                        + '</div>'
                        + '</div>');
                    $(".progress-bar").addClass("bg-success");
                    progressval(100);
                    setTimeout(function () {
                        $.unblockUI({
                            onUnblock: function () {
                                // location.reload();
                                window.location.replace("https://fazaa.ae")
                            }
                        });
                    }, 5000);
                }, 10000);
                // window.location("thankyou.html")
            }
            else {
                setTimeout(function () {
                    progressval(100);
                    $(".progress-bar").addClass("bg-danger");
                    $("div.panel-body h4").html('Something went wrong while submitting your application');
                }, 1000);
            }
        }, 5000);
    }

    var SaveRecords = function () {
        var Registerdata = {};
        const urlParams = new URLSearchParams(window.location.search);
        const emParam = urlParams.get('em');
        console.log(emParam)
        Registerdata.Subscrp_ID = 2
        Registerdata.CCID = 710
        Registerdata.Level_ID = 4

        Registerdata.Name_ar = $('#FirstName').val();
        Registerdata.Name_en = $('#FirstName').val();
        Registerdata.Email = $('#Email').val();
        Registerdata.Mobile = $('#Mobile').val();

        Registerdata.Nationalityid = 226;
        Registerdata.DOB = "01-01-2002";
        Registerdata.Gender = 1;
        Registerdata.EmiratesIdNo = "784-0000-0000000-0";
        Registerdata.Expiry = "01-04-2022";
        Registerdata.nameOnCard = $('#FirstName').val();
        Registerdata.SOF_IDPF = 1
        Registerdata.SOF_IDSM = 3
        Registerdata.Residence_emirate = 1
        Registerdata.terms = 1
        Registerdata.reg_password = emParam
        Registerdata.Lang_ID = 1

        console.log(JSON.stringify(Registerdata))
        if ($.isEmptyObject(Registerdata) != true) {
            return Save_CallHandler("https://fz.fazaa.ae/mmsapilv/api/Discount", JSON.stringify(Registerdata));
        }
    }

    var progressval = function (value) {
        var $div = $('div.progress-bar');
        $div.attr('aria-valuenow', value);
        $div.css('width', value + '%');
        $div.text(value + '% Complete');
    }


    let timeElm = document.getElementById('timer');
    let timer = function (x) {
        if (x === 0) {
            return;
        }
        timeElm.innerHTML = "QR Code expires in " + x + " seconds";
        // return setTimeout(() => { timer(--x) }, 1000)
    }

    return {
        //main function to initiate the module
        init: function () {
            var deferred = $.Deferred();
            deferred
                .then(function () {
                    $.ajaxSetup({ cache: false });
                    PageBlock();
                })
                .then(function () {
                    OnFormLoad();
                })
                .then(function () {
                    handleFormValidation();
                })
                .then(function () {
                    setTimeout(function () { $.unblockUI(); }, 1000);
                });
            deferred.resolve();
        }
    };

}();


$(document).ready(function () {
    $("#qr_container").hide()
    FormValidation.init();
});